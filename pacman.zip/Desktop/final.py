import msvcrt
import subprocess as sp
import time
import sys
import random

game_map = [
"#######################################################################",
"#                                                                     #",
"#   ########   #########   ###############   ####################     #",
"#   #      #   #       #   #             #   #                  #     #",
"#   #      #   #       #   #             #   #                  #     #",
"#   #      #   #       #   #             #   #                  #     #",
"#   #      #   #       #   #             #   #                  #     #",
"#   ########   #########   ###############   ####################     #",
"#                                $                                    #",
"#   ############################   ##############################     #",
"#   #                          #   #                            #     #",
"#   #                          #   #                            #     #",
"#   #                          #   #                            #     #",
"#   #                          #   #                            #     #",
"#   #                          #   #                            #     #",
"#   #                          #   #                            #     #",
"#   #                          #   #                            #     #",
"#   #                          #   #                            #     #",
"#   ############################   ##############################     #",
"#                                                                     #",
"#######################################################################"
]
game_map = [[x for x in s] for s in game_map]

char1 = 8
char2 = 33
count_play = 0

dir = [
    (-1,  0),
    ( 0,  1),
    ( 1,  0),
    ( 0, -1),
]

#Distance calculation

def get_dist(a, b):
    # return (((a[0]-b[0])##2 + (a[1]-b[1])##2)##0.5)
    return (abs(a[0]-b[0])+abs(a[1]-b[1]))

# 10 22

# mulai 8, 20
# slesai 1, 5

start = (2, 1)
end = (char1, char2)
#end_item = (random.randint(1,100),random.randint(1,200))
end_item = (9,66)

qu = []
qu.append((0, 0, start))
qu_1 = []
qu_1.append((0, 0, end))

game_map[3][66] = 'I'
game_map[9][66] = 'I'
game_map[16][66] = 'I'

while len(qu) > 0:
    # Ghost Movement
    qu_1 = sorted(qu_1, key=lambda x: x[0])
    qu = sorted(qu, key = lambda x: x[0])
    
    h_dist_1, dist_1, pos_1 = qu_1.pop(0)
    h_dist, dist, pos = qu.pop(0)

    game_map[pos_1[0]][pos_1[1]] = 'P'
    game_map[pos[0]][pos[1]] = 'G'
    
    
    # Character Movement
    currheur = 99999
    tnpos_1 =(8,33)
    for d in dir:
        npos_1 = (pos_1[0]+d[0], pos_1[1]+d[1])
        if game_map[npos_1[0]][npos_1[1]] == ' ' or game_map[npos_1[0]][npos_1[1]] == 'I'and\
            0 <= npos_1[0] < len(game_map) and\
            0 <= npos_1[1] < len(game_map[0]):
                nhdist_1 = dist_1+get_dist(npos_1, end_item)
                if(nhdist_1<currheur):
                    currheur = nhdist_1
                    tnpos_1 = npos_1
                    print(nhdist_1)
    qu_1.append((currheur, dist_1+1, tnpos_1))
    
    

    #Ghost Movement Calculation
    currheur = 99999
    tnpos =(2,1)
    for d in dir:
        npos = (pos[0]+d[0], pos[1]+d[1])
        if game_map[npos[0]][npos[1]] == ' ' or game_map[npos[0]][npos[1]] == 'P'and\
            0 <= npos[0] < len(game_map) and\
            0 <= npos[1] < len(game_map[0]):
                nhdist = dist+get_dist(npos, end)
                if(nhdist<currheur):
                    currheur = nhdist
                    tnpos = npos
                    print(nhdist)
    qu.append((currheur, dist+1, tnpos))
    sp.call('cls',shell=True)
    for l in game_map:
        for r in l:
            #print(r,end='')
            sys.stdout.write(r)
        print()
    
    game_map[pos_1[0]][pos_1[1]] = ' '
    game_map[pos[0]][pos[1]] = ' '
    end = pos_1
    
    if pos == end:
        break
    if pos_1 == end_item and count_play == 0:
        count_play = count_play+1
        end_item=(16,67)
    elif pos_1 == end_item and count_play == 1:
        count_play = count_play+1
        end_item = (3,66)
    elif pos_1 == end_item and count_play == 2:
        count_play = count_play+1
        end_item = (9,66)
    elif count_play == 3:
        break


    time.sleep(0.1)
