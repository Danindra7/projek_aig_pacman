import msvcrt
import subprocess as sp
import time
import sys
import random
import pygame

# defining tiles
M = 0 
P = 1 
E = 2
I = 3

# define tile color
BLUE = (0,0,255)
YELLOW = (255,255,0)
BLACK = (0,0,0)
FOOD = (122,134,123)

TileColor = {
    M: BLUE,#Wall
    E: YELLOW,#Pacman
    P: BLACK, #way
    I : FOOD #Food
}

game_map = [[M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M],
        [M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,I,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M],
        [M,P,P,P,M,M,M,M,M,M,M,M,P,P,P,M,M,M,M,M,M,M,M,M,P,P,P,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,P,P,P,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,P,P,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,M,M,M,M,M,M,M,P,P,P,M,M,M,M,M,M,M,M,M,P,P,P,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,P,P,P,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,P,P,P,P,P,M],
        [M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,E,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M],
        [M,P,P,P,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,P,P,P,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,P,I,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M,P,P,P,P,P,M],
        [M,P,P,P,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,P,P,P,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,P,P,P,P,P,M],
        [M,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,P,M],
        [M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M,M]
        ]


TILESIZE = 10
WIDTH_MAP = 71
HEIGHT_MAP = 21

# creating display
pygame.init()
DISPLAY = pygame.display.set_mode((WIDTH_MAP*TILESIZE, HEIGHT_MAP*TILESIZE))
# DISPLAY.fill(black)

# Basic UI

while True:
    for event in pygame.event.get():

        # quit 
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    
    # draw map 
    for row in range(HEIGHT_MAP):
        for col in range(WIDTH_MAP):
            if( game_map[row][col] == 2):
                pygame.draw.rect(DISPLAY, TileColor[game_map[row][col]], ((col*TILESIZE)+(TILESIZE/2), (row*TILESIZE)+(TILESIZE/2), 5, 5))
            elif( game_map[row][col] == 1):
                pygame.draw.rect(DISPLAY, TileColor[game_map[row][col]], (col*TILESIZE+2, row*TILESIZE+2, TILESIZE-4, TILESIZE-4))
            else:        
                pygame.draw.rect(DISPLAY, TileColor[game_map[row][col]], (col*TILESIZE, row*TILESIZE, TILESIZE, TILESIZE))

    pygame.display.update()